<!DOCTYPE html>
<html>
<head>
	<title>Form Data</title>
</head>
<body>
	<h2>Form Data</h2>
	<p>Name: <?php echo $_POST['name']; ?></p>
    <p>Pr Number: <?php echo $_POST['Pr']; ?></p>
	<p>Email: <?php echo $_POST['email']; ?></p>
	<p>Phone: <?php echo $_POST['phone']; ?></p>
	<p>Major: <?php echo $_POST['major']; ?></p>
	<p>Year: <?php echo $_POST['year']; ?></p>
</body>
</html>
