function validateForm() {
    var name = document.getElementById("name").value;
    var Pr = document.getElementById("Pr").value;
    var email = document.getElementById("email").value;
    var phone = document.getElementById("phone").value;
    var major = document.getElementById("major").value;
    var year = document.getElementById("year").value;


    if (name == "") {
        alert("Name must be filled out");
        return false;
    }else if (Pr == "") {
        alert("Pr No required");
        return false;
    }  else if (email == "") {
        alert("Email must be filled out");
        return false;
    } else if (phone == "") {
        alert("Phone must be filled out");
        return false;
    } else if (major == "") {
        alert("Major must be selected");
        return false;
    } else if (year == "") {
        alert("Year must be selected");
        return false;
    }

    return true;
}    